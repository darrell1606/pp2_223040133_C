package src;

import ui.MainFrame;

public class MainApp {
    public static void main(String[] args) {
        new MainFrame();
    }
}

