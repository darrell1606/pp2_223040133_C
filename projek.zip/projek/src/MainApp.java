import ui.MainFrame;

public class MainApp {
    public static void main(String[] args) {
        // Menjalankan antarmuka utama aplikasi
        javax.swing.SwingUtilities.invokeLater(() -> new MainFrame());
    }
}
